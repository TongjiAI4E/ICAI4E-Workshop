#!/usr/bin/env bash
# Compile the AI4E 2026 poster-paper template with pdflatex + bibtex.
# Requires a TeX distribution (TeX Live / MiKTeX) on the PATH.
set -e
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode main
bibtex main
pdflatex -interaction=nonstopmode main
pdflatex -interaction=nonstopmode main
echo "Done: main.pdf"
