# AI4E 2026 Poster-Paper LaTeX Template / 2026 国际工程智能大会 Poster 论文 LaTeX 模板

**2026 International Conference on AI for Engineering (AI4E 2026)**
Lingang Center, Shanghai · 31 October – 1 November 2026
Poster organizer: Institute of AI for Engineering, Tongji University

本模板基于 CVPR / ICCV 官方 author kit（[cvpr-org/author-kit](https://github.com/cvpr-org/author-kit)）及其社区扩展 [cvpr-latex-template](https://github.com/apoorvkh/cvpr-latex-template) 的文件组织形式改写而成：双栏、10 pt、US Letter，页边距、字体、标题样式与 CVPR/ICCV 完全一致。**Poster 论文不限页数。** 编译后的 `main.pdf` 即为模板说明文档，其中包含大会信息、投稿说明、格式要求、图/表/算法/公式/引用示例以及写作建议。

## 📁 目录结构 / Layout

| 文件 / 目录 | 作用 | 是否需要修改 |
| --- | --- | --- |
| `main.tex` | 入口文件：选择编译模式、按顺序 `\input` 各章节 | ✔ |
| `_constants.tex` | 题目、作者、单位、Paper ID、大会元信息 | ✔ |
| `_define.tex` | 论文专用宏（方法名、表格样式、颜色、定理环境） | ✔ |
| `_macros.tex` | 宏包与通用数学记号（如 `\vx`、`\mW`、`\E`、`\argmin`） | 可选 |
| `sec/0_abstract.tex` … `sec/5_conclusion.tex` | 摘要与正文各章节 | ✔ |
| `figs/*.tex`, `figs/*.pdf` | 图环境（单栏图、通栏图、子图）与图片文件 | ✔ |
| `tables/*.tex` | 表格与算法环境（单栏表、通栏表、并排小表、子表、算法） | ✔ |
| `A-sections/*.tex`, `A-figs/` | 附录及附录图 | ✔ |
| `cite.bib` | BibTeX 参考文献（顶部定义了会议缩写） | ✔ |
| `ai4e.sty` | 大会样式文件（版式、字体、评审模式），由 `cvpr.sty` 改写 | ✘ 请勿修改 |
| `ai4e_header.tex` | 样式选择、hyperref、cleveref | ✘ |
| `ieeenat_fullname.bst` | 参考文献样式（全名、数字编号） | ✘ |
| `latexmkrc`, `compile.bat`, `compile.sh` | 编译辅助 | ✘ |
| `poster_template/` | 配套 PowerPoint Poster 模板（48 in × 24 in）及其 PDF / 预览图 / Logo，详见其中的 README | ✔ |

## 🚀 快速开始 / Quick start

1. 在 `_constants.tex` 中填写题目、作者、单位、邮箱和 Paper ID。
2. 在 `main.tex` 第 6 行选择编译模式：`\review`（匿名评审稿）、`\cameraready`（终稿，默认）、`\arxiv`（预印本）。
3. 用自己的内容替换 `sec/` 下各文件；图放在 `figs/`、表放在 `tables/`，每个图/表一个 `.tex` 文件并在正文中 `\input`。
4. 在 `cite.bib` 中添加参考文献，用 `\cite{}` / `\citet{}` 引用；用 `\cref{}` 交叉引用。
5. 编译：

```bash
latexmk -pdf main
```

或手动执行 `pdflatex main` → `bibtex main` → `pdflatex main` → `pdflatex main`（Windows 可直接双击 `compile.bat`，Unix 运行 `./compile.sh`）。Overleaf：上传整个目录的 zip，主文档设为 `main.tex`，编译器选 pdfLaTeX。

## 🔧 编译模式 / Compilation modes

| 模式 | 效果 |
| --- | --- |
| `\review` | 隐藏作者信息，显示 "Anonymous AI4E submission / Paper ID"，页边加行号，每页加 "CONFIDENTIAL REVIEW COPY" 水印，显示页码 |
| `\cameraready` | 显示作者信息、页码，以及首页底部的大会信息脚注（在 `ai4e_header.tex` 中加 `nofooter` 选项可去掉；去掉 `pagenumbers` 选项可隐藏页码） |
| `\arxiv` | 同终稿；`\supp` 展开为 "appendix" |
| `\rebuttal` | 作者回复（无标题区，可用 `\R{1}`、`\R{2}` 指代审稿人） |

## 🧩 示例文件 / Examples

- 单栏图：`figs/Fig1.tex`；通栏图：`figs/Teaser.tex`；子图：`figs/Subfig.tex`；附录多面板图：`A-figs/grid.tex`
- 单栏表：`tables/key_dates.tex`、`tables/font_sizes.tex`（tabularx 自动换行见 `tables/submission_glance.tex`）
- 通栏结果表（分组表头、高亮行、最优/次优标记）：`tables/main_results.tex`
- 三个并排小表：`tables/ablation_all.tex`；子表：`tables/subtables.tex`
- 算法：`tables/algo_example.tex`
- 公式、定理环境、多行推导：`sec/3_method.tex`、`A-sections/2-exp.tex`

示例图由 `matplotlib` 导出为矢量 PDF（`pdf.fonttype = 42`，避免 Type 3 字体）。

## ❓ 常见问题 / FAQ

- **缺少宏包**：完整安装 TeX Live / MiKTeX 即可；最小安装需补 `silence cleveref lineno caption axessibility accsupp sttools xstring footmisc algorithms algorithmicx wrapfig placeins colortbl multirow microtype enumitem`。
- **Type 3 字体**：通常来自图片而非 LaTeX；请用矢量 PDF 并嵌入字体，用 `pdffonts main.pdf` 检查。
- **通栏图/表出现在下一页**：这是 LaTeX 双栏模式的固有行为，请尽早 `\input` 通栏浮动体。
- **中文投稿**：若大会允许中文稿件，可改用 XeLaTeX 并在 `_macros.tex` 中加入 `\usepackage{xeCJK}`（并删除 `main.tex` 中的 `\pdfoutput=1`）；投稿语言以大会通知为准。
- **发表政策**：Workshop 论文接收不影响后续投稿会议与期刊（模板中以粗体标出）。
- **待公布事项**：投稿语言、匿名要求、Poster 尺寸及投稿入口以大会网站公布为准；模板正文中相应位置标注为 "to be announced"，请组织方在公布后更新 `sec/2_related.tex` 与 `tables/submission_glance.tex`。

## 📄 版权 / Credits

`ai4e.sty` 与 `ieeenat_fullname.bst` 分别改自 CVPR 2025 author kit 的 `cvpr.sty` 与 `ieeenat_fullname.bst`（LaTeX Project Public License）。文件组织形式参考 [cvpr-latex-template](https://github.com/apoorvkh/cvpr-latex-template)。

Poster 征集联系邮箱：tangkaihua@tongji.edu.cn
