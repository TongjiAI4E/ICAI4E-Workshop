@echo off
rem Compile the AI4E 2026 poster-paper template with pdflatex + bibtex.
rem Requires a TeX distribution (TeX Live / MiKTeX) on the PATH.
cd /d "%~dp0"
pdflatex -interaction=nonstopmode main || goto :error
bibtex main || goto :error
pdflatex -interaction=nonstopmode main || goto :error
pdflatex -interaction=nonstopmode main || goto :error
echo.
echo Done: main.pdf
goto :eof

:error
echo.
echo Compilation failed -- see main.log / main.blg for details.
exit /b 1
