# AI4E 2026 Poster Template / 2026 国际工程智能大会 Poster 模板

- `AI4E2026_Poster_Template.pptx` — PowerPoint 模板（单页，48 in × 24 in，横版 2:1）
- `AI4E2026_Poster_Template.pdf` — 模板导出的 PDF（供预览 / 打印测试）
- `AI4E2026_Poster_Template_preview.png` — 预览图
- `assets/logo_IAIE_white.png`、`assets/logo_IAIE_color.png` — 工程智能研究院 Logo（白色版用于深色底，彩色版用于浅色底）

模板由《CVPR Workshop ONLY Poster Template》（Genigraphics 版式）修改而来：保留其页面尺寸、四栏结构、栏目标题条与底部 Contact / References 区，替换为大会配色（藏青 `092D65`、蓝 `125BC3`、浅蓝 `EDF4FD`）、研究院 Logo、大会信息以及面向本次 Poster 征集的填写说明；示例图表与 LaTeX 论文模板中的示例一致。

## 使用方法

1. 用 PowerPoint 打开 `AI4E2026_Poster_Template.pptx`（Google Slides / WPS 亦可，字体可能略有差异）。
2. 替换标题、作者、单位；左上角放置本单位 Logo（右上角为大会 / 研究院 Logo，请保留）。
3. 用自己的内容替换五个栏目（Abstract、Method、Results、Discussion、Conclusions）中的说明文字；栏目名称可以自由修改，建议保留标题条样式。
4. 图片请使用矢量图（EMF/SVG）或 300 dpi 以上的 PNG；表格请直接用 PowerPoint 表格（示例见 Table 1）。
5. 正文字号不小于 24 pt（推荐 32 pt），标题 54 pt，栏目标题 32 pt。
6. 左下角 QR code 占位框可替换为指向论文、代码或项目主页的二维码。
7. 保存时勾选“嵌入字体”（文件 → 选项 → 保存），并另存一份 PDF 一并提交。

## 说明

- 所有入选 Poster 由大会主办方统一打印并于 2026 年 11 月 1 日现场展示；最终打印尺寸与文件格式以大会通知为准（模板按 48 in × 24 in 设计，可等比缩放）。
- 投稿截止 2026 年 10 月 10 日，入选通知 10 月 15 日；现场评选 1 篇 Best Paper Award、2–3 篇 Best Paper Runner-Up Awards，所有入选 Poster 获入选证书。
- 模板中的会议信息与 LaTeX 论文模板保持一致；政策更新后请同步修改两处。
